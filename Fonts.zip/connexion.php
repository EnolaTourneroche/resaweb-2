<?php
$db = new PDO ('mysql:host=localhost;charset=utf8;dbname=spacetravel', 'root', '');
?>